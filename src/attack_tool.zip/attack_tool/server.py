from flask import Flask, render_template, request, jsonify
import subprocess
import threading
import sys
import os

app = Flask(__name__)

# Global state for attack process
attack_process = None

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/status')
def status():
    global attack_process
    is_running = attack_process is not None and attack_process.poll() is None
    return jsonify({"running": is_running})

@app.route('/api/stop', methods=['POST'])
def stop_attack():
    global attack_process
    if attack_process:
        attack_process.terminate()
        attack_process = None
        return jsonify({"status": "stopped", "message": "Attack stopped successfully"})
    return jsonify({"status": "not_running", "message": "No attack running"})

@app.route('/api/attack', methods=['POST'])
def start_attack():
    global attack_process
    data = request.json
    target_ip = data.get('target_ip')
    port = data.get('port', 80)
    threads = data.get('threads', 100)
    
    if not target_ip:
        return jsonify({"error": "Target IP required"}), 400
        
    if attack_process and attack_process.poll() is None:
        return jsonify({"error": "Attack already running"}), 409
        
    # Path to local stress test script
    script_path = os.path.join(os.path.dirname(__file__), '..', 'utils', 'network_stress_test.py')
    script_path = os.path.abspath(script_path)
    
    # Launch attack as subprocess
    try:
        cmd = [sys.executable, script_path, target_ip, str(port), str(threads)]
        attack_process = subprocess.Popen(cmd)
        return jsonify({"status": "started", "pid": attack_process.pid, "target": target_ip})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    print("😈 Red Team Attack Dashboard starting on port 5000...")
    app.run(host='0.0.0.0', port=5000)
